function mayus(e) {
    e.value = e.value.toUpperCase();
}